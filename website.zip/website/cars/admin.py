from django.contrib import admin
from .models import Car, Brand, Color, Order, Category
# Register your models here.

admin.site.register(Brand)
admin.site.register(Color)
admin.site.register(Category)
admin.site.register(Car)
admin.site.register(Order)