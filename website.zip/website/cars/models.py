from django.db import models
from .utils import calculate_tax


class Brand(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name='Название бренда',
        null=True
    )
    image = models.ImageField(
        upload_to='brands',
        null=True,
        verbose_name='Изображение бренда'
    )

    class Meta:
        verbose_name = 'Бренд'
        verbose_name_plural = 'Бренды'

    def __str__(self):
        return self.name

class Color(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name='Название цвета',
        null=True
    )

    class Meta:
        verbose_name = 'Цвет'
        verbose_name_plural = 'Цвета'

    def __str__(self):
        return self.name

class Category(models.Model):
    CATEGORY_CHOICES = (
        ('Новые', 'Новые'),
        ('С пробегом', 'С пробегом'),
    )
    name = models.CharField(
        max_length=255,
        choices=CATEGORY_CHOICES,
        verbose_name='Название категории'
    )

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'

    def __str__(self):
        return self.name


class Car(models.Model):
    brand = models.ForeignKey(
        Brand,
        on_delete=models.CASCADE,
        verbose_name='Бренд',
        null=True
    )
    name = models.CharField(
        max_length=255,
        verbose_name='Название авто',
        null=True
    )
    horsepower = models.IntegerField(
        null=True,
        verbose_name='Лошадиные силы'
    )
    category = models.ForeignKey(
        Category, 
        on_delete=models.CASCADE,
        verbose_name='Категория авто',
        null=True,
    )
    description = models.TextField(
        verbose_name='Описание',
        null=True
    )
    color = models.ForeignKey(
        Color,
        on_delete=models.CASCADE,
        verbose_name='Цвет',
        null=True,
    )
    DRIVE_CHOICES = (
        ('Передний', 'Передний'),
        ('Задний', 'Задний'),
        ('4WD', '4WD')
    )
    drive = models.CharField(
        choices=DRIVE_CHOICES,
        max_length=255,
        verbose_name='Привод',
        null=True
    )
    mileage = models.IntegerField(
        verbose_name='Пробег',
        null=True
    )
    release_year = models.IntegerField(
        verbose_name='Год выпуска',
        null=True
    )
    price = models.IntegerField(
        verbose_name='Цена',
        null=True
    )
    image = models.ImageField(
        upload_to='cars',
        null=True,
        verbose_name='Изображение'
    )

    class Meta:
        verbose_name = 'Автомобиль'
        verbose_name_plural = 'Автомобили'

    def __str__(self):
        return f'{self.name} - {self.brand} \
            (пробег - {self.mileage}, г.в. - {self.release_year})'

    @property
    def tax(self):
        '''Метод рассчёта налога'''
        return calculate_tax(self.horsepower)


class Order(models.Model):
    phone_number = models.CharField(
        max_length=20,
        verbose_name='Номер телефона',
        null=True
    ) 
    date = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Дата заявки',
        null=True
    )
    car = models.ForeignKey(
        Car,
        on_delete=models.CASCADE,
        verbose_name='Выбранный автомобиль',
        blank=True,
        null=True
    )
    called = models.BooleanField(
        default=False,
        verbose_name='Прозвонили'
    )

    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'

    def __str__(self):
        if self.called is True:
            return self.phone_number + '(Прозвонена)'
        return self.phone_number + '(Не прозвонена)'