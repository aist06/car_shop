from django.urls import path
from . import views

urlpatterns = [
    path('', views.MainPageView.as_view(), name='main'),
    path('brand/<int:brand_id>/', views.BrandDetailView.as_view(), name='brand_detail'),
    path('car/<int:car_id>/', views.CarDetailView.as_view(), name='car_detail'),
    path('services/', views.ServicesView.as_view(), name='services')
]