import requests

def calculate_tax(horsepower):
    '''Функция рассчёта налога'''
    if horsepower <= 100:
        tax_rate = 11
    elif 100 < horsepower <= 150:
        tax_rate = 15
    elif 150 < horsepower <= 200:
        tax_rate = 30
    elif 200 < horsepower <= 250:
        tax_rate = 75
    elif horsepower > 250:
        tax_rate = 150
    return tax_rate * horsepower

def send_tg_message(text, chat_id=408341261):
    method = "sendMessage"
    # telegram bot token
    token = "1886713251:AAFel0pa9SF1F2j_nnlMUbinr1DbbpEpjto"
    # API url
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = {"chat_id": chat_id, "text": text}
    requests.post(url, data=data)