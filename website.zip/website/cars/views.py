from django.shortcuts import render, redirect
from django.views.generic import TemplateView
from .models import Order, Brand, Category, Car
from .utils import send_tg_message
# Create your views here.

class MainPageView(TemplateView):
    template_name = 'cars/main.html'
    brands = None
    categories = None
    order_sent = False

    def get(self, request):
        self.brands = Brand.objects.all()
        self.categories = Category.objects.all()
        return super(MainPageView, self).get(request)

    def post(self, request):
        # Получение номера из отправленной формы
        phone_number = request.POST.get('phone_number')
        # Проверка правильности номера телефона
        allowed_chars = ['+', '(', ')', ' ']
        try:
            [int(phone_number.strip(char)) for char in allowed_chars]
        except:
            return redirect('main')
        # Создание новой заявки
        order = Order.objects.create(phone_number=phone_number)
        text = f'Оформлена завка на консультацию.\n\
            Номер клиента: {phone_number}.'
        # отправка ссобщения в телеграм-боте
        send_tg_message(text=text)
        self.order_sent = True
        return super(MainPageView, self).get(request)

    def get_context_data(self, **kwargs):
        context = super(MainPageView, self).get_context_data(**kwargs)
        context['brands'] = self.brands
        context['categories'] = self.categories
        context['order_sent'] = self.order_sent
        return context
    
class BrandDetailView(TemplateView):
    template_name = 'cars/brand_detail.html'
    brand = None
    category = None
    cars = None

    def get(self, request, brand_id):
        self.brand = Brand.objects.get(id=brand_id)
        try:
            category_id = int(request.GET.get('category'))
            self.category = Category.objects.get(id=category_id)
        except:
            self.category = None
        self.cars = Car.objects.filter(brand=self.brand)
        if self.category:
            self.cars = self.cars.filter(category=self.category)
        return super(BrandDetailView, self).get(request)

    def get_context_data(self, **kwargs):
        context = super(BrandDetailView, self).get_context_data(**kwargs)
        context['brand'] = self.brand
        context['category'] = self.category
        context['cars'] = self.cars
        return context

class CarDetailView(TemplateView):
    template_name = 'cars/car_detail.html'
    car = None
    order_sent = False

    def get(self, request, car_id):
        self.car = Car.objects.get(id=car_id)
        return super(CarDetailView, self).get(request)  
    
    def post(self, request, car_id):
        self.car = Car.objects.get(id=car_id)
        # Получение номера из отправленной формы
        phone_number = request.POST.get('phone_number')
        # Проверка правильности номера телефона
        allowed_chars = ['+', '(', ')', ' ']
        try:
            [int(phone_number.strip(char)) for char in allowed_chars]
        except:
            return redirect('car_detail', car_id=car_id)
        if phone_number:
            order = Order.objects.create(phone_number=phone_number, car=self.car)
            self.order_sent = True
            text = f'Оформлена завка на консультацию по'\
                f'покупке автомобиля {self.car.brand.name} '\
                f'{self.car.name}({self.car.color.name}, '\
                f'{self.car.release_year}г.в.).\n'\
                f'Номер телефона: {phone_number}'
            send_tg_message(text)
            return super(CarDetailView, self).get(request)
        return redirect('car_detail', car_id=car_id)

    def get_context_data(self, **kwargs):
        context = super(CarDetailView, self).get_context_data(**kwargs)
        context['car'] = self.car
        context['order_sent'] = self.order_sent
        return context
    

class ServicesView(TemplateView):
    template_name = 'cars/services.html'