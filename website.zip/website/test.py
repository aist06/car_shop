from django.db import models

class Brand(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name='название бренда',
        null=True
    )
    image = models.ImageField(
        upload_to='brands',
        null=True,
        verbose_name='Изображение бренда'
    )
    ...

class Color(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name='Название цвета',
        null=True
    )
    ...

